# dexcomapi


This simple package allows you to setup a authenticated channel to download blood glucose numbers from the Dexcom api. The intent is to use this with HomeAssistant.io.

 You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.